getwd()
setwd("C:\\Users\\IT24102844\\Desktop\\IT24102844")

data<- read.table("Exercise - LaptopsWeights.txt" , header = TRUE)
fix(data)
attach(data)

#Q1
popMean <- mean(Weight.kg.)
popSd <- sd(Weight.kg.)


#Q2
samples <- c()
sampleNames <- c()

for(i in 1:25) {
  s <- sample(Weight.kg., 6, replace=TRUE)
  samples <- cbind(samples, s)
  sampleNames <- c(sampleNames, paste("s", i))
}

colnames(samples) <- sampleNames

#Q3
sampleMeans <- apply(samples, 2, mean)
sample_sds <- apply(samples, 2, sd)

mean_of_sample_means <- mean(sampleMeans)
sd_of_sample_means <- sd(sampleMeans)

popMean
popSd
mean_of_sample_means
sd_of_sample_means