setwd("C:/Users/IT24102844/Desktop/IT24102844")

#importing the data set
DeliveryTimes <- read.table("Exercise - Lab 05.txt", header=TRUE, sep=",")

#View the data in a separate window
fix(DeliveryTimes)

names(DeliveryTimes) <- c("X1")

#Attach the file
attach(DeliveryTimes)

#Create breaks for 9 classes between 20 and 70
breaks <- seq(20, 70, length.out=10)

#Draw histogram with right-open intervals
histogram <- hist(X1,
     breaks=seq(20, 70, length.out=10),
     right=TRUE,
     main="Histogram for Delivery Times",
     xlab="Delivery Times (minutes)",
     ylab="Frequency",
     col="lightblue",
     border="black")

breaks <- round(histogram$breaks)

freq <- histogram$counts

mids <- histogram$mids

classes <- c()


for(i in 1:length(breaks)-1){
  classes[i] <- paste0("[" , breaks[i], "," , breaks[i+1], ")")
}

cbind(classes = classes, Frequency = freq)

lines(mids, freq)

plot(mids, freq, type = 'l', main = "Frequency Polygon for Delivery Times", xlab = "Delivery Times (minutes)",
     ylab = "Frequency", ylim = c(0.,max(freq)))


cum.freq <- cumsum(freq)

new <- c()

for(i in 1:length(breaks)){
  if (i==1) {
    new[i] = 0
  }else{
    new[i] = cum.freq[i-1]
  }
}

plot(breaks, new, type = 'l', main = "Cumulative Frequency Polygon", xlab="Delivery Times (minutes)",
     ylab="Cumulative Frequency", ylim = c(0.,max(cum.freq)))


cbind(Upper = breaks, CumFreq = new)

